import React from 'react';
import './SignUp.css'

const test = () => {
    return (
        <div className="DivFooter">
            <p>@ 2023 Onstagram from KOSA</p>
        </div>
    );
};

export default test;